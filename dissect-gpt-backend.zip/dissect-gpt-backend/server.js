import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { OpenAI } from "openai";

dotenv.config();
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const dissectSystemPrompt = `You are Reading Amigo’s Article Dissection Assistant, a professional-level GPT designed to help users deeply engage with nonfiction articles...

[🔁 PASTE YOUR FULL CUSTOM GPT PROMPT HERE IN PLACE OF THIS LINE]`;

app.post("/analyze", async (req, res) => {
  const userText = req.body.userText;
  if (!userText || userText.length < 100) {
    return res.status(400).json({ reply: "Text too short for analysis." });
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: dissectSystemPrompt },
        { role: "user", content: `Please analyze the following article:\n\n${userText}` }
      ],
      temperature: 0.4,
      max_tokens: 2800
    });
    res.json({ reply: response.choices[0].message.content });
  } catch (err) {
    res.status(500).json({ reply: "OpenAI API error" });
  }
});

app.listen(port, () => {
  console.log(`Dissect! backend running on port ${port}`);
});
